package ac1part2.ac1part2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ac1part2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
